package local_de_botanica;

import java.util.Objects;

public abstract class Planta 
{
    protected String nombre;
    protected String ubicacion;
    protected String clima;

        public Planta(String nombre, String ubicacion, String clima) 
        {
            this.nombre = nombre;
            this.ubicacion = ubicacion;
            this.clima = clima;
        }
        
        
        public String getNombre() 
        {
        return nombre;
        }
         
        @Override
        public boolean equals(Object obj)
        {
            if(obj == this)
                {
                    return true;
                }
            if(obj == null)
                {
                    return true;
                }
            if(obj instanceof Planta otherPlant)
                {
                    return nombre.equals(otherPlant.nombre) && ubicacion.equals(otherPlant.ubicacion);
                }
            return false;
        }
        
        @Override
        public int hashCode() 
        {
            return Objects.hash(nombre, ubicacion);
        }
   
        @Override
         public String toString()
         {
             return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + '}';
         }
   
   
    
   
   
   
}

    

   
   
 
   

