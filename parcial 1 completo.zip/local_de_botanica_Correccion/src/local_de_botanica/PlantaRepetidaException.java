package local_de_botanica;

public class PlantaRepetidaException extends Exception {
    public PlantaRepetidaException(String mensaje) {
        super(mensaje);
    }
}