
package local_de_botanica;


public interface Podable {
    boolean podar();
}
