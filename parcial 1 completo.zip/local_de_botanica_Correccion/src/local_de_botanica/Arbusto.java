package local_de_botanica;

public class Arbusto extends Planta
{
    private static final int MAX_DENSIDAD = 10;
    private static final int MIN_DENSIDAD = 1;
    private int densidad;
    private boolean podado;     
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidad) 
    {
        super(nombre, ubicacion, clima);
        this.densidad = densidad;
        this.podado = false;
        this.densidad = densidad;
    }

    public boolean podar() 
    {
        if (!podado) {
            podado = true;
            System.out.println("El arbusto " + nombre + " ha sido podado.");
            return true;
        } else {
            System.out.println("El arbusto " + nombre + " ya estaba podado.");
            return false;
        }
    }
    
    public boolean validaDensidad() 
    {
        return densidad >= MIN_DENSIDAD && densidad <= MAX_DENSIDAD;
    }
    
    public String getNombre() 
    {
        return nombre; // Acceso al atributo nombre heredado de Planta
    }
    
    
    @Override
    public String toString() 
    {
        return "Arbusto{" + super.toString()+ "densidad=" + densidad + ", podado=" + podado + '}';
    }
    
    
    
}

