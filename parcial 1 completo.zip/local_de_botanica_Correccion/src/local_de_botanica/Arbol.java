package local_de_botanica;

public class Arbol extends Planta implements Podable
{
    
    
    private int alturaMaxima;
    private boolean podado; 
    
    
    
    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) 
    {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
        this.podado = false; 
    }

   
         
    @Override     
    public boolean podar() {
        if (!podado) {
            podado = true;
            System.out.println("El arbusto " + nombre + " ha sido podado.");
            return true;
        } else {
            System.out.println("El arbusto " + nombre + " ya estaba podado.");
            return false;
        }
    }
    
    public String getNombre() 
    {
        return nombre; // Acceso al atributo nombre heredado de Planta
    }
    
    
    @Override
    public String toString()
    {
        return "Arbol{" + super.toString()+ "alturaMaxima" + alturaMaxima + '}';
    }
    
    
}
