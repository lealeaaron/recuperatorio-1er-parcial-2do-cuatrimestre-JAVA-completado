package local_de_botanica;

import java.util.ArrayList;

public class Botanica {
    private ArrayList<Planta> listadoPlantas;

    //crea listado de plantas
    public Botanica() {
        listadoPlantas = new ArrayList<>();
    }

    
    public void agregarPlanta(Planta planta) throws PlantaRepetidaException 
    {
        if (listadoPlantas.contains(planta))
        {
            throw new PlantaRepetidaException("La planta " + planta.getNombre() + " ya está en el listado.");
        }
        listadoPlantas.add(planta);
    }

    // podar las plantas
    public void podarPlantas() 
    {
        for (Planta planta : listadoPlantas) 
        {
            if (planta instanceof Arbusto) 
            {
                Arbusto arbusto = (Arbusto) planta;
                arbusto.podar();  // Llamada al método podar() en Arbusto
                
            } 
            else if (planta instanceof Arbol) 
            {
                Arbol arbol = (Arbol) planta;
                arbol.podar();  // Llamada al método podar() en Arbol
                
                
            }            
        }
    }

    // mostrar las plantas
    public void mostrarPlantas() {
        System.out.println("Listado de Plantas:");
        for (Planta planta : listadoPlantas) {
            System.out.println(planta.toString()); // Llama al método toString() de cada planta
        }
    }

    // main 
    public static void main(String[] args) {
        Botanica botanica = new Botanica();

        try {
            // Crear plantas
            botanica.agregarPlanta(new Arbol("Pino", "Bosque", "Frio", 20));
            botanica.agregarPlanta(new Arbusto("Rosal", "Jardin", "Templado", 5));
            botanica.agregarPlanta(new Flor("Margarita", "Pradera", "Templado", Temporada.PRIMAVERA));
            botanica.agregarPlanta(new Arbol("Roble", "Montania", "Templado", 30));
            botanica.agregarPlanta(new Arbusto("Lavanda", "Jardin", "Mediterraneo", 6));

            // Intentar agregar una planta repetida
            botanica.agregarPlanta(new Arbol("Pino", "Bosque", "Frio", 20)); // Esto lanzará una excepción
        } catch (PlantaRepetidaException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        // Podar las plantas
        botanica.podarPlantas();

        // Mostrar las plantas
        botanica.mostrarPlantas();

        // Ejemplo adicional con Arbusto
        Arbusto arbusto = new Arbusto("Rosa", "Jardín", "Templado", 5);
        System.out.println("¿La densidad es válida? " + arbusto.validaDensidad());
    }
}
