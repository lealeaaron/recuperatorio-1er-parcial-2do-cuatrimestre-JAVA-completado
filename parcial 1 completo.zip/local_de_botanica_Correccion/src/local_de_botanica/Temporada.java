package local_de_botanica;

public enum Temporada 
{
    OTOÑO,
    INVIERNO,
    PRIMAVERA,
    VERANO;  
}
